package classpart;

public class Person {
	
	String name;
	int height;
	double weight;
	char gender;
	boolean married;
}
