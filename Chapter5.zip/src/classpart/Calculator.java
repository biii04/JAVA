package classpart;

public class Calculator {
	
	public int add(int n1, int n2) {
		int result = n1 + n2;
		return result;
	}
	

	public static void main(String[] args) {
		
		
		int num1 = 10;
		int num2 = 2;
		
		
	}
}
