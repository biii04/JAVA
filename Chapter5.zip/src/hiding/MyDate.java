package hiding;

public class MyDate {
	
	public int day;
	public int month;
	public int year;

}
