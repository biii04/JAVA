package reference;

public class Subject {

	String subjectName;
	int scorePoint;
}
