package arithmetic;

public class OperationEx2 {
	 public static void main(String[] args) {
		 int mathScore = 90;
		 int engScore = 70;
		
		  int totalScore = mathScore + engScore;
		  System.out.println(totalScore);

		  int avgScore = (mathScore + engScore) / 2;
		  System.out.println(avgScore);
	 }
}
