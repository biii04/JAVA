package bitop;

public class OperationEx10 {

	public static void main(String[] args) {

		int num = 10;
		
		System.out.println(~num);
	}
}
