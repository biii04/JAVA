package bitop;

public class OperationEx8 {

	public static void main(String[] args) {
		
		int num1 = 5;
		int num2 = 10;
		
		int result = num1 | num2;
		System.out.println(result);
	}
}
