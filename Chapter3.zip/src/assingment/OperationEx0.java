package assingment;

public class OperationEx0 {

	public static void main(String[] args) {

		int num1 = 10;
		int value;
		
		value = num1 + 10;
		num1 = value;
		System.out.println(num1);
		System.out.println(value);
	}
}
