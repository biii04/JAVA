package chapter3;

public class Q3 {

	public static void main(String[] args) {
		int num = 10;
		
		System.out.println(num);
		System.out.println(num++);
		System.out.println(num);
		System.out.println(--num);
	}
}
