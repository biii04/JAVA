package chapter2;

public class Q5 {

	public static void main(String[] args) {

		char ch = '\uAE00';
		System.out.println(ch);
	}
}
