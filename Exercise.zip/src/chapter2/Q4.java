package chapter2;

public class Q4 {
	public static void main(String[] args) {
		int i = 10;
		double j = 2.0;
		
		System.out.println((int)(i + j));
		System.out.println((int)(i - j));
		System.out.println((int)(i * j));
		System.out.println((int)(i / j));
	}
}
