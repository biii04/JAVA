package chapter6.q5;

public class Menu {

	public static final int STARAMERICANO = 4000;
	public static final int STARLATTE = 4300;
	
	public static final int BEANAMERICANO = 4100;
	public static final int BEANLATTE = 4500;
}
