package chapter13.q5;

public class CalcTest {

	public static void main(String[] args) {

		Calc sum = (x,y)->x + y;
		
		System.out.println(sum.add(20,  30));
	}

}
