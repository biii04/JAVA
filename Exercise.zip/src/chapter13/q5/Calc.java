package chapter13.q5;

@FunctionalInterface
public interface Calc {

	public int add(int num1, int num2);
}
