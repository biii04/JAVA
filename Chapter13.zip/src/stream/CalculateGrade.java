package stream;

public class CalculateGrade {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
