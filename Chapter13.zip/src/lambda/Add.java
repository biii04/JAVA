package lambda;

@FunctionalInterface
public interface Add {

	public int add(int x, int y);
}
