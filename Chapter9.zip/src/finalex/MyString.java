package finalex;

public class MyString extends String{

}
