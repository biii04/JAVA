package downcasting;

class Animal {

}
