package virtualfunction;

public class TestB extends TestA{
	
	

}
