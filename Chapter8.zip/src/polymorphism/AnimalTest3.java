package polymorphism;


public class AnimalTest3 {
	
	 public static void main(String[] args) {
		 Animal ani = new Tiger();
		 Human h = (Human)ani;

	 }

	

}



