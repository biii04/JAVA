package chapter4;

import java.io.IOException;

public class IfExample1 {

	public static void main(String[] args) throws IOException {
		
		char gender = 'F';
		//char gender = 'M';
		
		if( gender == 'F' ){
			System.out.println("�����Դϴ�.");
		}
		else{
			System.out.println("�����Դϴ�.");
		}
	}
}
