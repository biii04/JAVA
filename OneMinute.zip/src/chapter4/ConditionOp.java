package chapter4;

public class ConditionOp {

	public static void main(String[] args) {
		int num = 10;
		boolean isEven;
		isEven = (num % 2) == 0? true : false;
		System.out.println(isEven);
	}
}
