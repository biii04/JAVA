package chapter11.object;

public class StudentTest {

	public static void main(String[] args) {
		Student studentKim = new Student(1001, "������");
		System.out.println(studentKim);
	}
}
