package chapter4;

public class ForExample1 {

	public static void main(String[] args) {

		int i;
		for(i=1; i<=10; i++){
		
		   System.out.println("�ȳ��ϼ���" + i);	
		}
	}
}
