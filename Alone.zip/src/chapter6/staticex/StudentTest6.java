package chapter6.staticex;

public class StudentTest6 {

	public static void main(String[] args) {

		Student3 studentKim = new Student3();
		System.out.println("�й�: " + studentKim.studentID + ", ī�� ��ȣ: " + studentKim.cardNumber);
		
		Student3 studentLee = new Student3();
		System.out.println("�й�: " + studentLee.studentID + ", ī�� ��ȣ: " + studentLee.cardNumber);
	}
}
