package chapter10.scheduler;

public interface Scheduler {

	public void getNextCall();
	public void sendCallToAgent();
	
}
