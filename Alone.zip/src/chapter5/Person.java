package chapter5;

public class Person {
	int age;
	String name;
	boolean isMarried;
	int numberOfChildren;
}
