package chapter2;

public class Hexadecimal {

	public static void main(String[] args) {

		int num1 = 16;
		int num2 = 020;
		int num3 = 0x10;
		
		System.out.println(num1);
		System.out.println(num2);
		System.out.println(num3);
	}
}
