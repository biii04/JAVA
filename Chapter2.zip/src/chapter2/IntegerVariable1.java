package chapter2;

public class IntegerVariable1 {

	public static void main(String[] args) {

		int iVal_1 = 10;
		int iVal_2 = 20;
		
		int result = iVal_1 + iVal_2;
		
		System.out.println( result );
	}
}
