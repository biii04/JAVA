package chapter2;

public class ByteVariable {

	public static void main(String[] args) {

		byte bs1 = -128;
	//	byte bs2 = 128;
		
		System.out.println(bs1);
		//System.out.println(bs2);
		
		//short s = 33000;
		//System.out.println(s);
	}
}
