package chapter2;

public class LongVariable {

	public static void main(String[] args) {

		//int num1 = 12345678900;
		long num2 = 12345678900L;
		long num3 = 1000;
		
		System.out.println(num2 + num3);
	}
}
