package chapter2;

public class IntegerVariable {

	public static void main(String[] args) {

		short sVal = 10;
		byte  bVal = 20;
		System.out.println( sVal + bVal );
	}
}
