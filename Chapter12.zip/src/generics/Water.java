package generics;

public class Water {

}
