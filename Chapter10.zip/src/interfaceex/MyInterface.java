package interfaceex;

public interface MyInterface extends X, Y{

	void myMethod();
}
